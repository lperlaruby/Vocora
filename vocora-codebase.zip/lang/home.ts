"use client";

// lang/home.ts

const homeTransla = {
    en: {
      title: "Hello",
    },
    es: {
      title: "Hola",
    },
    zh: {
      title: "你好",
    },
  } as const;
  
  export default homeTransla;
  